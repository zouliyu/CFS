sudo bdmflash /dev/bdmcf0 0xffe00000 1 2 write o-optimize/osal.exe 0x0 
