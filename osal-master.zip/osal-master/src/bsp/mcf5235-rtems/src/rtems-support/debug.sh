sudo /opt/rtems-4.10/bin/m68k-rtems4.10-gdb --command=gdb-init test1.nxe
