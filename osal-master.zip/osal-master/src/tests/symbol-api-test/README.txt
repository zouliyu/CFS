Explanation:

symtest tests the symbol table API in the OSAL



