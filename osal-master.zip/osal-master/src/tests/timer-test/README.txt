This example tests the OS_Timer API.  
